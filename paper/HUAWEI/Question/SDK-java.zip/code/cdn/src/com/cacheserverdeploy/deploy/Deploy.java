package com.cacheserverdeploy.deploy;


public class Deploy
{
    /**
     * todo
     * 
     * @param graphContent caseinfo
     * @return  caseouput info
     * @see [huawei]
     */
    public static String[] deployServer(String[] graphContent)
    {
        /**do your work here**/
        return new String[]{"17","\r\n","0 8 0 20"};
    }

}
