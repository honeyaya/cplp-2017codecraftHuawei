#include "deploy.h"
#include <stdio.h>
#include <stdlib.h>
#include <queue>
#include <iostream>
#include <vector>
#include <string>
#include <ctime> 
#include <cstring>
#include <algorithm>
#include <map>
#include <set>
#include <stack>
using namespace std;

const int inf = 0x3f3f3f3f;
const int N = 1500;

struct edge{
	int from,to,cap,cost,flow;
};

vector<edge> e;
vector<edge> ec;
vector<int> v[N];
vector<int> vc[N];

vector<int> demand;
vector<int> directNode;

int mincost;
int supers,supert;
int serverDeployCost;
int netNum,edgeNum,consumerNum,vNum;

vector<int> vis(N,0);
vector<int> dis(N,0);
vector<int> p(N,-1);
vector<int> a(N,-1);

vector<int> J0;
vector<int> J2;

vector<int> path;
vector<int> pathflow;

void addedge(int from,int to,int cap,int cost,int flow){
	e.push_back((edge){from,to,cap,cost,0});
	e.push_back((edge){to,from,0,-cost,0});
			
	int len = e.size() - 1;
	v[to].push_back(len);
	v[from].push_back(len-1);	
}	

void initMCMF(){
	for(int i = 0; i < N; i++){
		p[i] = -1;
		a[i] = -1;
	}
	for(int i = 0; i < (int)dis.size(); i++)
    	dis[i] = inf;
    for(int i = 0; i < (int)vis.size(); i++)
    	vis[i] = 0;
}

void initJ2(vector<int>J1,int s){
	J2.clear();
	for(int i = 0; i < (int)J1.size();i++){
		if(J1[i]!=s) {
			J2.push_back(J1[i]);
		}
			
	}
}


bool MCMF(int s,int t,int& flow, int & cost){
	
	initMCMF();
    	
    dis[s] = 0;
    vis[s] = 1;
    p[s] = 0;
    a[s] = inf;
    queue<int> q;
    
    q.push(s);
    while(!q.empty())
    {
        int u = q.front();
        q.pop();
        vis[u] = 0;
        for(int i=0; i< (int)v[u].size(); i++)
        {
            edge& g = e[v[u][i]];
            if(g.cap>g.flow && dis[g.to] > dis[u]+g.cost)
            {
                dis[g.to] = dis[u] + g.cost;
                p[g.to] = v[u][i];  //����ǰ��
                a[g.to] = min(a[u],g.cap-g.flow);
                if(!vis[g.to])
                {
                    q.push(g.to);
                    vis[g.to]=1;
                }

            }
        }
    }
    if(dis[t] == inf)
        return false;
    flow += a[t];
    cost += dis[t]*(a[t]);
    int u = t;
    while(u!=s)
    {
        e[p[u]].flow += a[t];
        e[p[u]^1].flow -= a[t];
        u = e[p[u]].from;
    }
    return true;
}

bool MCMF2(int s,int t,int& flow, int & cost){
	
	initMCMF();
	
    dis[s] = 0;
    vis[s] = 1;
    p[s] = 0;
    a[s] = inf;
    queue<int> q;
    
    q.push(s);
    while(!q.empty())
    {
        int u = q.front();
        q.pop();
        vis[u] = 0;
        for(int i=0; i< (int)v[u].size(); i++)
        {
            edge& g = e[v[u][i]];
            if(g.cap>g.flow && dis[g.to] > dis[u]+g.cost)
            {
                dis[g.to] = dis[u] + g.cost;
                p[g.to] = v[u][i];  //����ǰ��
                a[g.to] = min(a[u],g.cap-g.flow);
                if(!vis[g.to])
                {
                    q.push(g.to);
                    vis[g.to]=1;
                }

            }
        }
    }
    if(dis[t] == inf)
        return false;
    flow += a[t];
    cost += dis[t]*(a[t]);
    int u = t;
    while(u!=s)
    {
    	path.push_back(u);
    	pathflow.push_back(flow);
        e[p[u]].flow += a[t];
        e[p[u]^1].flow -= a[t];
        u = e[p[u]].from;
    }
    return true;
}

void repaint(vector<int> sc){
	
	for(int i = 0; i < (int)sc.size();i++){
		e.push_back((edge){supers,sc[i],inf,0,0});
		e.push_back((edge){sc[i],supers,0,0,0});
		int len = e.size() - 1;
		v[sc[i]].push_back(len);
		v[supers].push_back(len-1);
	}
}

void evinit(){
	e.clear();
	for(int i = 0; i < (int)ec.size();i++)
		e.push_back(ec[i]);
	for(int i = 0;i < N;i++){
		v[i].clear();
		for(int j = 0; j < (int)vc[i].size();j++){
			v[i].push_back(vc[i][j]);
		}
	}
}

void deploy_server(char * topo[MAX_EDGE_NUM], int line_num,char * filename)
{
				
		vector<int> J1;
			
	    clock_t start = clock();		
		
		sscanf(topo[0],"%d %d %d",&netNum,&edgeNum,&consumerNum);
		
		sscanf(topo[2],"%d",&serverDeployCost);
		
		vNum = netNum + consumerNum;
		// construct the ori graph
		for(int i = 4; i < 4 + edgeNum; i++) {
			int from,to,cap,cost;
			sscanf(topo[i],"%d %d %d %d",&from,&to,&cap,&cost);
			addedge(from,to,cap,cost,0);
			addedge(to,from,cap,cost,0);
		}
		
		//add the topo about the consumer
		int totalneed = 0;
		for(int i = 5 + edgeNum; i < 5 + edgeNum + consumerNum; i++) {
			int from,to,cap;
			sscanf(topo[i],"%d %d %d",&from,&to,&cap);
			from = from + netNum;
			totalneed += cap;
			
			addedge(to,from,cap,0,0);
			//addedge(to,from,0,0,0);
			 
			demand.push_back(cap);
			directNode.push_back(to);
			J1.push_back(to);
		}
		
		//add the supert
		supert = vNum + 1;
		for(int i = 0; i < consumerNum; i++){
			e.push_back((edge){i+netNum,supert,demand[i],0,0}); 
			e.push_back((edge){supert,i+netNum,0,0,0}); 
			int len = e.size() - 1;
			v[supert].push_back(len);
			v[i+netNum].push_back(len-1);	
		}
		
		//cout <<"e size : "<< e.size() << endl;
		
		// backup the graph 
		for(int i = 0; i < (int)e.size(); i++){
			ec.push_back(e[i]);
		}	
		for(int i = 0; i < N; i++){
			for(int j = 0; j < (int)v[i].size();j++){
				vc[i].push_back(v[i][j]);
			}
		}	
		
		// the oricost
		mincost = 0; supers = vNum;
		
		//greedy algorithm to delete the ori set J1
		
		while(1) {
			
			if((clock()-start) > 75*CLOCKS_PER_SEC){   // time is out
				break;
			}
			/*
			cout << "J1 is :" << endl;
			for(int i = 0; i < (int)J1.size(); i++){
				cout << J1[i] << " " ;
			}
			cout << endl;
			*/
			if((int)J1.size() == consumerNum){
				mincost = 0;
			} else{
				repaint(J1);
				int flow = 0, cost = 0;
				while(MCMF(supers,supert,flow,cost));
				evinit();
				//cout << "flow:" << flow << endl;
				mincost = cost;
			}
			vector<int> deletepos;
			int delta = 0;
			int maxdelta = -100000000;
			
				
			for(int i = 0; i < (int)J1.size(); i++)	{
				if((clock()-start) > 75*CLOCKS_PER_SEC){   // time is out
					break;
				}
				initJ2(J1,J1[i]);
				repaint(J2);
				
				int flow = 0, cost = 0;
				while(MCMF(supers,supert,flow,cost));
				//cout << "flow:" << flow << " cost:" << cost << endl;
				
				evinit();
				if(flow == totalneed){
					delta = serverDeployCost + mincost - cost;
					if(delta > maxdelta) {
						maxdelta = delta;
						deletepos.clear();
						deletepos.push_back(J1[i]); 
					}
					if(delta == maxdelta){
						deletepos.push_back(J1[i]);
					}
				}	
			}
			
			if(maxdelta > 0){
				vector<int> tmp;
				for(int i = 0; i < (int)J1.size(); i++){
					vector<int>:: iterator iter = find(deletepos.begin(),deletepos.end(),J1[i]);
					if(iter == deletepos.end())	{
						tmp.push_back(J1[i]);
					} else{
						J0.push_back(J1[i]);
					}
				}
				J1.clear();
				for(int i = 0; i < (int)tmp.size();i++){
					J1.push_back(tmp[i]);
				} 
				deletepos.clear();
			}
			else{
				break;
			}
				
		}
		
		
		repaint(J1);
		int onetotalflow = 0, onetotalcost = 0;
		while(MCMF(supers,supert,onetotalflow,onetotalcost));
		//cout << "onetotalflow: " << onetotalflow << " onetotalcost: " << onetotalcost << endl;
		
		ec.clear();
		for(int i = 0; i < N;i++)
			vc[i].clear();
				
		for(int i = 0; i < (int)e.size();i++){
			if(e[i].flow > 0) {
				ec.push_back((edge){e[i].from,e[i].to,e[i].flow,e[i].cost,0});
				ec.push_back((edge){e[i].to,e[i].from,e[i].flow,e[i].cost,0});
				
				
				int len = ec.size() - 1;
				vc[e[i].to].push_back(len);
				vc[e[i].from].push_back(len-1);
			}
		}
		
		evinit();
		repaint(J1);
		onetotalflow = 0, onetotalcost = 0;
		while(MCMF2(supers,supert,onetotalflow,onetotalcost));
		cout << "consumerNum : " << consumerNum << " totalneed" << totalneed <<endl;
		cout << "flow:" << onetotalflow << " server is: " <<  J1.size() << " cost is:" << onetotalcost + J1.size() *  serverDeployCost << endl;
		//cout << "onetotalflow: " << onetotalflow << " onetotalcost: " << onetotalcost << endl;
		//cout << "----------------------" << endl;
		
		
		// output to the file
		
		string output;
		vector<string> recordpath;
		string onepath;
		for(int i = (int)path.size()-1; i >= 0; i--){
			if(path[i] == supert){
				if(i>0)
					onepath += to_string(pathflow[i] - pathflow[i-1]);
				else 
					onepath += to_string(pathflow[0]);
				recordpath.push_back(onepath); 
				onepath = "";
			} else {
				if(path[i-1] == supert){
					path[i] -= netNum;
				}
				onepath += to_string(path[i]) + " ";
			}
		}
		
		output = to_string(recordpath.size());
		output += "\n\n";
		
		for(int i = 0; i < (int)recordpath.size() - 1;i++){
			output += recordpath[i] + "\n";
		} 
		output += recordpath[recordpath.size()-1];
		
		char * topo_file = (char *)output.c_str();
	    write_result(topo_file, filename);
	    return ;
		    
}



